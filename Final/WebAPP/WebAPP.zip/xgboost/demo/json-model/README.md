We introduced initial support for saving XGBoost model in JSON format in 1.0.0.  Note that
it's still experimental and under development, output schema is subject to change due to
bug fixes or further refactoring.  For an overview, see https://xgboost.readthedocs.io/en/latest/tutorials/saving_model.html .