######################
XGBoost Python Package
######################
This page contains links to all the python related documents on python package.
To install the package, checkout :doc:`Installation Guide </install>`.

********
Contents
********

.. toctree::
  python_intro
  python_api
  callbacks
  model
  Python examples <https://github.com/dmlc/xgboost/tree/master/demo/guide-python>
